CREATE TABLE users (
   id INTEGER PRIMARY KEY ,
   name TEXT
);