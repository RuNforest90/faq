CREATE TABLE IF NOT EXISTS test (
    id INT PRIMARY KEY,
    name_123 TEXT
)

INSERT INTO test (id, name_123) VALUES (1, "abc"), (2, "abcd"), (3, "qwerty")